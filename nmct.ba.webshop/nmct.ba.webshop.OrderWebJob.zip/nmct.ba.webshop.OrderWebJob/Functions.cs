﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using nmct.ba.webshop.models;
using Newtonsoft.Json;
using nmct.ba.webshop.Services;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Storage.Queue;
using nmct.ba.webshop.models.Repositories;
using nmct.ba.webshop.repositories;

namespace nmct.ba.webshop.OrderWebJob
{
    public class Functions
    {
        // This function will get triggered/executed when a new message is written 
        // on an Azure Queue called queue.
        public static void ProcessQueueMessage([QueueTrigger("orders")] string message, TextWriter log)
        {
            BasketRepository repoBasket = new BasketRepository();
            OrderQueueRepository repoOrderQueue = new OrderQueueRepository();
            BasketService bs = new BasketService(repoBasket, repoOrderQueue);

            Order orderInfo = JsonConvert.DeserializeObject<Order>(message);
            bs.saveOrder(orderInfo);
        }
    }
}
